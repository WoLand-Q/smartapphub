<?php
session_start();

// If already logged in, redirect accordingly
if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
        header('Location: admin.php');
    } else {
        header('Location: index.php');
    }
    exit;
}

$dataDir = __DIR__ . '/data';
$usersFile = $dataDir . '/users.json';
$error = '';

// Handle login submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    if ($username !== '' && $password !== '') {
        if (file_exists($usersFile)) {
            $json = file_get_contents($usersFile);
            $users = json_decode($json, true) ?: [];
            $found = false;
            foreach ($users as $user) {
                if ($user['username'] === $username) {
                    $hash = hash('sha256', $password);
                    if (hash_equals($user['password_hash'], $hash)) {
                        $_SESSION['logged_in'] = true;
                        $_SESSION['role'] = $user['role'];
                        $_SESSION['username'] = $user['username'];
                        $found = true;
                        // redirect based on role
                        if ($user['role'] === 'admin') {
                            header('Location: admin.php');
                        } else {
                            header('Location: index.php');
                        }
                        exit;
                    }
                }
            }
            if (!$found) {
                $error = 'Невірний логін або пароль.';
            }
        } else {
            $error = 'Файл з користувачами не знайдений.';
        }
    } else {
        $error = 'Введіть логін та пароль.';
    }
}
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Адмінська авторизація</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="light.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            opacity: 0;
        }
        .login-container {
            max-width: 400px;
            margin: 100px auto;
        }
    </style>
</head>
<body data-theme="default" data-layout="fluid" data-sidebar-position="left" data-sidebar-layout="default">
    <div class="login-container">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title mb-4">Вхід для адміністратора</h4>
                <?php if ($error): ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>
                <form method="post">
                    <div class="mb-3">
                        <label class="form-label">Логін</label>
                        <input type="text" class="form-control" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Пароль</label>
                        <input type="password" class="form-control" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Увійти</button>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            feather.replace();
            document.body.style.opacity = '1';
        });
    </script>
</body>
</html>