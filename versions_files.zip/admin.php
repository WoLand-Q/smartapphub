<?php
session_start();

// Redirect to login page if not authenticated or not admin
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

$dataDir = __DIR__ . '/data';
$pluginsDir = __DIR__ . '/plugins_files';
// Directory for uploaded documentation files
$docsDir = __DIR__ . '/docs_files';

// Ensure directories exist
if (!is_dir($dataDir)) {
    mkdir($dataDir, 0777, true);
}
if (!is_dir($pluginsDir)) {
    mkdir($pluginsDir, 0777, true);
}
if (!is_dir($docsDir)) {
    mkdir($docsDir, 0777, true);
}

// Load news and plugins
$newsFile = $dataDir . '/news.json';
$pluginsFile = $dataDir . '/plugins.json';
// Load docs
$docsFile = $dataDir . '/docs.json';

$news = [];
if (file_exists($newsFile)) {
    $jsonNews = file_get_contents($newsFile);
    $news = json_decode($jsonNews, true) ?: [];
}

$plugins = [];
if (file_exists($pluginsFile)) {
    $jsonPlugins = file_get_contents($pluginsFile);
    $plugins = json_decode($jsonPlugins, true) ?: [];
}

// Load docs
$docs = [];
if (file_exists($docsFile)) {
    $jsonDocs = file_get_contents($docsFile);
    $docs = json_decode($jsonDocs, true) ?: [];
}

// Helper to slugify plugin names
function slugify_admin($text) {
    $text = preg_replace('~[\pP\pZ]+~u', '-', $text);
    $text = strtolower($text);
    $text = trim($text, '-');
    return $text ?: 'plugin';
}

// Load releases
$releasesFile = $dataDir . '/releases.json';
$releases = [];
if (file_exists($releasesFile)) {
    $jsonRel = file_get_contents($releasesFile);
    $releases = json_decode($jsonRel, true) ?: [];
}

// Helper to slugify release names (version names)
function slugify_release($text) {
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = trim($text, '-');
    $text = strtolower($text);
    return $text ?: 'release';
}

// Process admin actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['admin_action'] ?? '';
    switch ($action) {
        case 'logout':
            session_destroy();
            header('Location: login.php');
            exit;
        case 'add_news':
            $title = trim($_POST['news_title'] ?? '');
            $content = trim($_POST['news_content'] ?? '');
            if ($title !== '' && $content !== '') {
                $news[] = [
                    'title' => $title,
                    'content' => $content,
                    'date' => date('Y-m-d')
                ];
                file_put_contents($newsFile, json_encode($news, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                $_SESSION['admin_message'] = 'Новина додана.';
            } else {
                $_SESSION['admin_error'] = 'Заповніть усі поля для новини.';
            }
            header('Location: admin.php');
            exit;
        case 'edit_news':
            $index = (int)($_POST['news_index'] ?? -1);
            $title = trim($_POST['edit_news_title'] ?? '');
            $content = trim($_POST['edit_news_content'] ?? '');
            if ($index >= 0 && $index < count($news)) {
                if ($title !== '' && $content !== '') {
                    $news[$index]['title'] = $title;
                    $news[$index]['content'] = $content;
                    file_put_contents($newsFile, json_encode($news, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                    $_SESSION['admin_message'] = 'Новина оновлена.';
                } else {
                    $_SESSION['admin_error'] = 'Поля не можуть бути порожніми.';
                }
            }
            header('Location: admin.php');
            exit;
        case 'delete_news':
            $index = (int)($_POST['news_index'] ?? -1);
            if ($index >= 0 && $index < count($news)) {
                array_splice($news, $index, 1);
                file_put_contents($newsFile, json_encode($news, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                $_SESSION['admin_message'] = 'Новина видалена.';
            }
            header('Location: admin.php');
            exit;
        case 'add_plugin':
            $name = trim($_POST['plugin_name'] ?? '');
            $desc = trim($_POST['plugin_desc'] ?? '');
            if ($name !== '' && $desc !== '') {
                $slug = slugify_admin($name);
                $counter = 1;
                $existingSlugs = array_column($plugins, 'slug');
                $baseSlug = $slug;
                while (in_array($slug, $existingSlugs)) {
                    $slug = $baseSlug . '-' . $counter;
                    $counter++;
                }
                $plugins[] = [
                    'slug' => $slug,
                    'name' => $name,
                    'description' => $desc,
                    'versions' => []
                ];
                file_put_contents($pluginsFile, json_encode($plugins, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                $_SESSION['admin_message'] = 'Плагін додано.';
            } else {
                $_SESSION['admin_error'] = 'Заповніть усі поля для плагіна.';
            }
            header('Location: admin.php');
            exit;
        case 'add_release':
            // Add a new release
            $name = trim($_POST['release_name'] ?? '');
            if ($name !== '') {
                $slug = slugify_release($name);
                // ensure unique slug
                $existingSlugs = array_column($releases, 'slug');
                $base = $slug;
                $c = 1;
                while (in_array($slug, $existingSlugs)) {
                    $slug = $base . '-' . $c;
                    $c++;
                }
                $releases[] = [
                    'slug' => $slug,
                    'name' => $name,
                    'categories' => [
                        'resume' => '',
                        'novelties' => '',
                        'forUkraine' => '',
                        'fixed' => '',
                        'important' => '',
                        'problems' => '',
                        'additions' => '',
                        'lifehacks' => ''
                    ]
                ];
                file_put_contents($releasesFile, json_encode($releases, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                $_SESSION['admin_message'] = 'Реліз додано.';
            } else {
                $_SESSION['admin_error'] = 'Назва релізу не може бути порожньою.';
            }
            header('Location: admin.php');
            exit;
        case 'edit_release':
            // Save edited release categories
            $slug = $_POST['release_slug'] ?? '';
            foreach ($releases as $idx => $rel) {
                if ($rel['slug'] === $slug) {
                    // update each category
                    $cats = $rel['categories'];
                    foreach ($cats as $key => $val) {
                        $field = 'cat_' . $slug . '_' . $key;
                        if (isset($_POST[$field])) {
                            $releases[$idx]['categories'][$key] = trim($_POST[$field]);
                        }
                    }
                    file_put_contents($releasesFile, json_encode($releases, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                    $_SESSION['admin_message'] = 'Реліз оновлено.';
                    break;
                }
            }
            header('Location: admin.php');
            exit;
        case 'delete_release':
            // Delete a release
            $slug = $_POST['release_slug'] ?? '';
            foreach ($releases as $idx => $rel) {
                if ($rel['slug'] === $slug) {
                    array_splice($releases, $idx, 1);
                    file_put_contents($releasesFile, json_encode($releases, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                    $_SESSION['admin_message'] = 'Реліз видалено.';
                    break;
                }
            }
            header('Location: admin.php');
            exit;
        case 'delete_plugin':
            $index = (int)($_POST['plugin_index'] ?? -1);
            if ($index >= 0 && $index < count($plugins)) {
                // Remove plugin directory and files
                $slug = $plugins[$index]['slug'];
                $dir = $pluginsDir . '/' . $slug;
                if (is_dir($dir)) {
                    $files = scandir($dir);
                    foreach ($files as $f) {
                        if ($f !== '.' && $f !== '..') {
                            unlink($dir . '/' . $f);
                        }
                    }
                    rmdir($dir);
                }
                array_splice($plugins, $index, 1);
                file_put_contents($pluginsFile, json_encode($plugins, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                $_SESSION['admin_message'] = 'Плагін видалено.';
            }
            header('Location: admin.php');
            exit;
        case 'add_doc':
            // Add documentation
            $title = trim($_POST['doc_title'] ?? '');
            $desc = trim($_POST['doc_desc'] ?? '');
            $link = trim($_POST['doc_link'] ?? '');
            if ($title !== '' && ($desc !== '' || $link !== '' || (isset($_FILES['doc_file']) && $_FILES['doc_file']['error'] === UPLOAD_ERR_OK))) {
                // Determine next ID
                $nextId = 1;
                if (count($docs) > 0) {
                    $ids = array_column($docs, 'id');
                    $nextId = max($ids) + 1;
                }
                $fileName = '';
                if (isset($_FILES['doc_file']) && $_FILES['doc_file']['error'] === UPLOAD_ERR_OK) {
                    $tmpName = $_FILES['doc_file']['tmp_name'];
                    $origName = basename($_FILES['doc_file']['name']);
                    $ext = pathinfo($origName, PATHINFO_EXTENSION);
                    $fileName = 'doc_' . $nextId . '_' . time() . '.' . $ext;
                    move_uploaded_file($tmpName, $docsDir . '/' . $fileName);
                }
                $docs[] = [
                    'id' => $nextId,
                    'title' => $title,
                    'description' => $desc,
                    'link' => $link,
                    'file' => $fileName,
                    'date' => date('Y-m-d')
                ];
                file_put_contents($docsFile, json_encode($docs, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                $_SESSION['admin_message'] = 'Документацію додано.';
            } else {
                $_SESSION['admin_error'] = 'Вкажіть назву та опис, посилання або файл.';
            }
            header('Location: admin.php');
            exit;
        case 'delete_doc':
            // Delete documentation
            $index = (int)($_POST['doc_index'] ?? -1);
            if ($index >= 0 && $index < count($docs)) {
                // Remove file if exists
                if (!empty($docs[$index]['file'])) {
                    $fpath = $docsDir . '/' . $docs[$index]['file'];
                    if (file_exists($fpath)) {
                        unlink($fpath);
                    }
                }
                array_splice($docs, $index, 1);
                file_put_contents($docsFile, json_encode($docs, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                $_SESSION['admin_message'] = 'Документацію видалено.';
            }
            header('Location: admin.php');
            exit;
        case 'edit_doc':
            // Edit documentation
            $index = (int)($_POST['doc_index'] ?? -1);
            $title = trim($_POST['edit_doc_title'] ?? '');
            $desc = trim($_POST['edit_doc_desc'] ?? '');
            $link = trim($_POST['edit_doc_link'] ?? '');
            if ($index >= 0 && $index < count($docs)) {
                if ($title !== '' && ($desc !== '' || $link !== '' || (isset($_FILES['edit_doc_file']) && $_FILES['edit_doc_file']['error'] === UPLOAD_ERR_OK))) {
                    $doc = &$docs[$index];
                    $doc['title'] = $title;
                    $doc['description'] = $desc;
                    $doc['link'] = $link;
                    // Handle file replacement
                    if (isset($_FILES['edit_doc_file']) && $_FILES['edit_doc_file']['error'] === UPLOAD_ERR_OK) {
                        // remove old file
                        if (!empty($doc['file'])) {
                            $oldPath = $docsDir . '/' . $doc['file'];
                            if (file_exists($oldPath)) {
                                unlink($oldPath);
                            }
                        }
                        $tmpName = $_FILES['edit_doc_file']['tmp_name'];
                        $origName = basename($_FILES['edit_doc_file']['name']);
                        $ext = pathinfo($origName, PATHINFO_EXTENSION);
                        $fileName = 'doc_' . $doc['id'] . '_' . time() . '.' . $ext;
                        move_uploaded_file($tmpName, $docsDir . '/' . $fileName);
                        $doc['file'] = $fileName;
                    }
                    $doc['date'] = date('Y-m-d');
                    file_put_contents($docsFile, json_encode($docs, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                    $_SESSION['admin_message'] = 'Документацію оновлено.';
                } else {
                    $_SESSION['admin_error'] = 'Вкажіть назву та опис, посилання або файл.';
                }
            }
            header('Location: admin.php');
            exit;
        case 'add_version':
            // Add new version for plugin
            $pluginSlug = $_POST['plugin_slug'] ?? '';
            $versionName = trim($_POST['version_name'] ?? '');
            $minVersion = trim($_POST['min_version'] ?? '');
            if ($pluginSlug && $versionName && $minVersion && isset($_FILES['version_file']) && $_FILES['version_file']['error'] === UPLOAD_ERR_OK) {
                // Find plugin index
                $pIndex = -1;
                foreach ($plugins as $idx => $pl) {
                    if ($pl['slug'] === $pluginSlug) {
                        $pIndex = $idx;
                        break;
                    }
                }
                if ($pIndex !== -1) {
                    $plugin = &$plugins[$pIndex];
                    // Ensure plugin directory exists
                    $pDir = $pluginsDir . '/' . $pluginSlug;
                    if (!is_dir($pDir)) {
                        mkdir($pDir, 0777, true);
                    }
                    $tmpName = $_FILES['version_file']['tmp_name'];
                    $origName = basename($_FILES['version_file']['name']);
                    $ext = pathinfo($origName, PATHINFO_EXTENSION);
                    // Create unique file name
                    $fileName = $pluginSlug . '_' . preg_replace('/[^A-Za-z0-9_\-\.]/', '', $versionName) . '_' . time() . '.' . $ext;
                    $dest = $pDir . '/' . $fileName;
                    move_uploaded_file($tmpName, $dest);
                    // Append version data
                    $plugin['versions'][] = [
                        'version' => $versionName,
                        'min_version' => $minVersion,
                        'date' => date('Y-m-d'),
                        'file' => $fileName
                    ];
                    file_put_contents($pluginsFile, json_encode($plugins, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                    $_SESSION['admin_message'] = 'Версію додано.';
                }
            } else {
                $_SESSION['admin_error'] = 'Заповніть усі поля для версії та завантажте файл.';
            }
            header('Location: admin.php');
            exit;
    }
}

// Capture admin messages
$adminMessage = $_SESSION['admin_message'] ?? '';
$adminError = $_SESSION['admin_error'] ?? '';
unset($_SESSION['admin_message'], $_SESSION['admin_error']);

?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Адмін панель</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="light.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            opacity: 0;
        }
    </style>
</head>
<body data-theme="default" data-layout="fluid" data-sidebar-position="left" data-sidebar-layout="default">
<div class="wrapper">
    <nav id="sidebar" class="sidebar js-sidebar">
        <div class="sidebar-content d-flex flex-column h-100">
            <a class='sidebar-brand' href='index.php'>
                <span class="sidebar-brand-text align-middle">
                    Syrve
                    <sup><small class="badge bg-primary text-uppercase">PULSE</small></sup>
                </span>
            </a>
            <!-- Navigation links -->
            <ul class="sidebar-nav flex-grow-1">
                <li class="sidebar-header">Адмін навігація</li>
                <li class="sidebar-item">
                    <a class='sidebar-link' href='index.php'>
                        <i class="align-middle" data-feather="home"></i> <span class="align-middle">Головна</span>
                    </a>
                </li>
                <li class="sidebar-item">
                    <a class='sidebar-link' href='admin.php'>
                        <i class="align-middle" data-feather="settings"></i> <span class="align-middle">Панель</span>
                    </a>
                </li>
            </ul>
            <!-- Logout button at bottom -->
            <form method="post" class="m-0">
                <input type="hidden" name="logout" value="1">
                <button type="submit" class="sidebar-link btn-as-link">
                    <i class="align-middle" data-feather="log-out"></i>
                    <span class="align-middle">Вихід</span>
                </button>
            </form>

        </div>
    </nav>
    <div class="main">
        <nav class="navbar navbar-expand navbar-light navbar-bg">
            <a class="sidebar-toggle js-sidebar-toggle">
                <i class="hamburger align-self-center"></i>
            </a>
        </nav>
        <main class="content">
            <div class="container-fluid p-0">
                <div class="row mb-3">
                    <div class="col">
                        <h3><strong>Адмін</strong> панель</h3>
                    </div>
                </div>
                <?php if ($adminMessage): ?>
                    <div class="alert alert-success alert-dismissible" role="alert">
                        <?php echo htmlspecialchars($adminMessage); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if ($adminError): ?>
                    <div class="alert alert-danger alert-dismissible" role="alert">
                        <?php echo htmlspecialchars($adminError); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <div class="row">
                    <div class="col-12 col-md-6">
                        <!-- News management -->
                        <div class="card mb-3">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Управління новинами</h5>
                            </div>
                            <div class="card-body">
                                <!-- Add news form -->
                                <h6 class="mb-3">Додати новину</h6>
                                <form method="post" class="mb-4">
                                    <input type="hidden" name="admin_action" value="add_news">
                                    <div class="mb-3">
                                        <label class="form-label">Заголовок</label>
                                        <input type="text" class="form-control" name="news_title" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Текст</label>
                                        <textarea class="form-control" name="news_content" rows="4" required></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Додати</button>
                                </form>
                                <!-- Existing news list for editing -->
                                <h6 class="mb-3">Існуючі новини</h6>
                                <?php if (count($news) > 0): ?>
                                    <?php foreach ($news as $i => $item): ?>
                                        <div class="card mb-2">
                                            <div class="card-body">
                                                <h5 class="card-title"><?php echo htmlspecialchars($item['title']); ?></h5>
                                                <h6 class="card-subtitle text-muted mb-2">
                                                    <?php echo htmlspecialchars($item['date']); ?>
                                                </h6>
                                                <p class="card-text"><?php echo nl2br(htmlspecialchars($item['content'])); ?></p>
                                                <button class="btn btn-sm btn-outline-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#editNewsAdmin<?php echo $i; ?>" aria-expanded="false" aria-controls="editNewsAdmin<?php echo $i; ?>">Редагувати</button>
                                                <form method="post" style="display:inline">
                                                    <input type="hidden" name="admin_action" value="delete_news">
                                                    <input type="hidden" name="news_index" value="<?php echo $i; ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Ви впевнені, що хочете видалити цю новину?');">Видалити</button>
                                                </form>
                                                <div class="collapse mt-3" id="editNewsAdmin<?php echo $i; ?>">
                                                    <form method="post">
                                                        <input type="hidden" name="admin_action" value="edit_news">
                                                        <input type="hidden" name="news_index" value="<?php echo $i; ?>">
                                                        <div class="mb-2">
                                                            <label class="form-label">Заголовок</label>
                                                            <input type="text" class="form-control" name="edit_news_title" value="<?php echo htmlspecialchars($item['title'], ENT_QUOTES); ?>" required>
                                                        </div>
                                                        <div class="mb-2">
                                                            <label class="form-label">Текст</label>
                                                            <textarea class="form-control" name="edit_news_content" rows="3" required><?php echo htmlspecialchars($item['content']); ?></textarea>
                                                        </div>
                                                            <button type="submit" class="btn btn-sm btn-success">Зберегти</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p>Новини відсутні.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <!-- Plugin management -->
                        <div class="card mb-3">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Управління плагінами</h5>
                            </div>
                            <div class="card-body">
                                <!-- Add plugin form -->
                                <h6 class="mb-3">Додати плагін</h6>
                                <form method="post" class="mb-4">
                                    <input type="hidden" name="admin_action" value="add_plugin">
                                    <div class="mb-3">
                                        <label class="form-label">Назва плагіна</label>
                                        <input type="text" class="form-control" name="plugin_name" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Опис</label>
                                        <textarea class="form-control" name="plugin_desc" rows="3" required></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Додати</button>
                                </form>
                                <!-- List existing plugins -->
                                <h6 class="mb-3">Існуючі плагіни</h6>
                                <?php if (count($plugins) > 0): ?>
                                    <div class="accordion" id="pluginAccordion">
                                        <?php foreach ($plugins as $idx => $pl): ?>
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="heading<?php echo $idx; ?>">
                                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo $idx; ?>" aria-expanded="false" aria-controls="collapse<?php echo $idx; ?>">
                                                        <?php echo htmlspecialchars($pl['name']); ?>
                                                    </button>
                                                </h2>
                                                <div id="collapse<?php echo $idx; ?>" class="accordion-collapse collapse" aria-labelledby="heading<?php echo $idx; ?>" data-bs-parent="#pluginAccordion">
                                                    <div class="accordion-body">
                                                        <p><strong>Опис:</strong> <?php echo htmlspecialchars($pl['description']); ?></p>
                                                        <p><strong>Версії:</strong></p>
                                                        <?php if (count($pl['versions']) > 0): ?>
                                                            <ul class="list-group mb-2">
                                                                <?php foreach ($pl['versions'] as $vIndex => $ver): ?>
                                                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                                                        <span>
                                                                            <?php echo htmlspecialchars($ver['version']); ?> (мін: <?php echo htmlspecialchars($ver['min_version']); ?>, дата: <?php echo htmlspecialchars($ver['date']); ?>)
                                                                        </span>
                                                                        <a class="btn btn-sm btn-outline-primary" href="plugins_files/<?php echo rawurlencode($pl['slug']); ?>/<?php echo rawurlencode($ver['file']); ?>" download>Скачати</a>
                                                                    </li>
                                                                <?php endforeach; ?>
                                                            </ul>
                                                        <?php else: ?>
                                                            <p>Версії відсутні.</p>
                                                        <?php endif; ?>
                                                        <!-- Form to add new version -->
                                                        <form method="post" enctype="multipart/form-data" class="mt-3">
                                                            <input type="hidden" name="admin_action" value="add_version">
                                                            <input type="hidden" name="plugin_slug" value="<?php echo htmlspecialchars($pl['slug']); ?>">
                                                            <div class="mb-2">
                                                                <label class="form-label">Назва версії</label>
                                                                <input type="text" class="form-control" name="version_name" required>
                                                            </div>
                                                            <div class="mb-2">
                                                                <label class="form-label">Мін. версія</label>
                                                                <input type="text" class="form-control" name="min_version" required>
                                                            </div>
                                                            <div class="mb-2">
                                                                <label class="form-label">Файл версії</label>
                                                                <input type="file" class="form-control" name="version_file" required>
                                                            </div>
                                                            <button type="submit" class="btn btn-sm btn-success">Додати версію</button>
                                                        </form>
                                                        <!-- Delete plugin button -->
                                                        <form method="post" class="mt-2">
                                                            <input type="hidden" name="admin_action" value="delete_plugin">
                                                            <input type="hidden" name="plugin_index" value="<?php echo $idx; ?>">
                                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Ви впевнені, що хочете видалити цей плагін?');">Видалити плагін</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <p>Плагіни відсутні.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6">
                        <!-- Documentation management -->
                        <div class="card mb-3">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Управління документацією</h5>
                            </div>
                            <div class="card-body">
                                <!-- Add documentation form -->
                                <h6 class="mb-3">Додати документ</h6>
                                <form method="post" enctype="multipart/form-data" class="mb-4">
                                    <input type="hidden" name="admin_action" value="add_doc">
                                    <div class="mb-2">
                                        <label class="form-label">Назва</label>
                                        <input type="text" class="form-control" name="doc_title" required>
                                    </div>
                                    <div class="mb-2">
                                        <label class="form-label">Опис</label>
                                        <textarea class="form-control" name="doc_desc" rows="3" required></textarea>
                                    </div>
                                    <div class="mb-2">
                                        <label class="form-label">Посилання (якщо є)</label>
                                        <input type="url" class="form-control" name="doc_link" placeholder="https://...">
                                    </div>
                                    <div class="mb-2">
                                        <label class="form-label">Файл (за бажанням)</label>
                                        <input type="file" class="form-control" name="doc_file">
                                    </div>
                                    <button type="submit" class="btn btn-primary">Додати</button>
                                </form>
                                <!-- Existing docs list -->
                                <h6 class="mb-3">Існуючі документи</h6>
                                <?php if (count($docs) > 0): ?>
                                    <?php foreach ($docs as $dIndex => $doc): ?>
                                        <div class="card mb-2">
                                            <div class="card-body">
                                                <h5 class="card-title mb-1"><?php echo htmlspecialchars($doc['title']); ?></h5>
                                                <h6 class="card-subtitle text-muted mb-2">
                                                    <?php echo htmlspecialchars($doc['date']); ?>
                                                </h6>
                                                <p class="card-text"><?php echo nl2br(htmlspecialchars($doc['description'])); ?></p>
                                                <?php if (!empty($doc['link'])): ?>
                                                    <a href="<?php echo htmlspecialchars($doc['link']); ?>" target="_blank" class="btn btn-sm btn-outline-primary">Переглянути</a>
                                                <?php endif; ?>
                                                <?php if (!empty($doc['file'])): ?>
                                                    <a href="docs_files/<?php echo rawurlencode($doc['file']); ?>" download class="btn btn-sm btn-primary">Скачати</a>
                                                <?php endif; ?>
                                                <button class="btn btn-sm btn-outline-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#editDoc<?php echo $dIndex; ?>" aria-expanded="false" aria-controls="editDoc<?php echo $dIndex; ?>">Редагувати</button>
                                                <form method="post" style="display:inline">
                                                    <input type="hidden" name="admin_action" value="delete_doc">
                                                    <input type="hidden" name="doc_index" value="<?php echo $dIndex; ?>">
                                                    <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Ви впевнені, що хочете видалити цей документ?');">Видалити</button>
                                                </form>
                                                <div class="collapse mt-3" id="editDoc<?php echo $dIndex; ?>">
                                                    <form method="post" enctype="multipart/form-data">
                                                        <input type="hidden" name="admin_action" value="edit_doc">
                                                        <input type="hidden" name="doc_index" value="<?php echo $dIndex; ?>">
                                                        <div class="mb-2">
                                                            <label class="form-label">Назва</label>
                                                            <input type="text" class="form-control" name="edit_doc_title" value="<?php echo htmlspecialchars($doc['title'], ENT_QUOTES); ?>" required>
                                                        </div>
                                                        <div class="mb-2">
                                                            <label class="form-label">Опис</label>
                                                            <textarea class="form-control" name="edit_doc_desc" rows="3" required><?php echo htmlspecialchars($doc['description']); ?></textarea>
                                                        </div>
                                                        <div class="mb-2">
                                                            <label class="form-label">Посилання</label>
                                                            <input type="url" class="form-control" name="edit_doc_link" value="<?php echo htmlspecialchars($doc['link']); ?>">
                                                        </div>
                                                            <div class="mb-2">
                                                                <label class="form-label">Замінити файл</label>
                                                                <input type="file" class="form-control" name="edit_doc_file">
                                                            </div>
                                                        <button type="submit" class="btn btn-sm btn-success">Зберегти</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p>Документи відсутні.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <!-- Release management -->
                    <div class="col-12 mt-3">
                        <div class="card mb-3">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Управління релізами</h5>
                            </div>
                            <div class="card-body">
                                <!-- Add release form -->
                                <h6 class="mb-3">Додати реліз</h6>
                                <form method="post" class="mb-4">
                                    <input type="hidden" name="admin_action" value="add_release">
                                    <div class="mb-2">
                                        <label class="form-label">Назва релізу (наприклад, Syrve 9.2.6029)</label>
                                        <input type="text" class="form-control" name="release_name" required>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Додати реліз</button>
                                </form>
                                <!-- Existing releases -->
                                <h6 class="mb-3">Існуючі релізи</h6>
                                <?php if (count($releases) > 0): ?>
                                    <div class="accordion" id="releaseAccordion">
                                        <?php foreach ($releases as $rIndex => $rel): ?>
                                            <div class="accordion-item mb-2">
                                                <h2 class="accordion-header" id="relHeading<?php echo $rIndex; ?>">
                                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#relCollapse<?php echo $rIndex; ?>" aria-expanded="false" aria-controls="relCollapse<?php echo $rIndex; ?>">
                                                        <?php echo htmlspecialchars($rel['name']); ?>
                                                    </button>
                                                </h2>
                                                <div id="relCollapse<?php echo $rIndex; ?>" class="accordion-collapse collapse" aria-labelledby="relHeading<?php echo $rIndex; ?>" data-bs-parent="#releaseAccordion">
                                                    <div class="accordion-body">
                                                        <form method="post">
                                                            <input type="hidden" name="admin_action" value="edit_release">
                                                            <input type="hidden" name="release_slug" value="<?php echo htmlspecialchars($rel['slug']); ?>">
                                                            <?php
                                                            $catNames = [
                                                                'resume' => 'Резюме',
                                                                'novelties' => 'Новинки',
                                                                'forUkraine' => 'Для України',
                                                                'fixed' => 'Виправлено',
                                                                'important' => 'Важливе',
                                                                'problems' => 'Відомі проблеми',
                                                                'additions' => 'Доповнення',
                                                                'lifehacks' => 'Лайфхаки'
                                                            ];
                                                            ?>
                                                            <?php foreach ($rel['categories'] as $cKey => $cVal): ?>
                                                                <div class="mb-2">
                                                                    <label class="form-label"><?php echo htmlspecialchars($catNames[$cKey] ?? ucfirst($cKey)); ?></label>
                                                                    <textarea class="form-control" name="<?php echo 'cat_' . $rel['slug'] . '_' . $cKey; ?>" rows="3"><?php echo htmlspecialchars($cVal); ?></textarea>
                                                                </div>
                                                            <?php endforeach; ?>
                                                            <button type="submit" class="btn btn-sm btn-success">Зберегти зміни</button>
                                                        </form>
                                                        <form method="post" class="mt-2">
                                                            <input type="hidden" name="admin_action" value="delete_release">
                                                            <input type="hidden" name="release_slug" value="<?php echo htmlspecialchars($rel['slug']); ?>">
                                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Ви впевнені, що хочете видалити цей реліз?');">Видалити реліз</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <p>Релізи відсутні.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        feather.replace();
        document.body.style.opacity = '1';
        document.querySelectorAll('.js-sidebar-toggle').forEach(function(toggle) {
            toggle.addEventListener('click', function() {
                document.querySelector('.sidebar').classList.toggle('collapsed');
            });
        });
    });
</script>
</body>
</html>