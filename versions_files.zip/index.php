<?php
// Start session to store messages (success, errors)
session_start();

// Define directories for data and uploads (revised for new structure)
$dataDir = __DIR__ . '/data';
$pluginsDir = __DIR__ . '/plugins_files';

// Ensure directories exist
if (!is_dir($dataDir)) {
    mkdir($dataDir, 0777, true);
}
if (!is_dir($pluginsDir)) {
    mkdir($pluginsDir, 0777, true);
}

// Load news and plugins
$newsFile = $dataDir . '/news.json';
$news = [];
if (file_exists($newsFile)) {
    $jsonNews = file_get_contents($newsFile);
    $news = json_decode($jsonNews, true) ?: [];
}

// Load plugins
$pluginsFile = $dataDir . '/plugins.json';
$plugins = [];
if (file_exists($pluginsFile)) {
    $jsonPlugins = file_get_contents($pluginsFile);
    $plugins = json_decode($jsonPlugins, true) ?: [];
}

// Handle POST actions for news (adding, editing, deleting)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Add news
    if (isset($_POST['action']) && $_POST['action'] === 'add_news') {
        $title = trim($_POST['news_title'] ?? '');
        $content = trim($_POST['news_content'] ?? '');
        if ($title !== '' && $content !== '') {
            $news[] = [
                'title' => $title,
                'content' => $content,
                'date' => date('Y-m-d H:i')
            ];
            file_put_contents($newsFile, json_encode($news, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            $_SESSION['message'] = 'Новина додана успішно.';
        } else {
            $_SESSION['error'] = 'Заголовок і текст новини не можуть бути порожніми.';
        }
        header('Location: ' . $_SERVER['PHP_SELF'] . '?page=news');
        exit;
    }
    // Edit news
    if (isset($_POST['action']) && $_POST['action'] === 'edit_news') {
        $index = (int)($_POST['news_index'] ?? -1);
        $title = trim($_POST['edit_news_title'] ?? '');
        $content = trim($_POST['edit_news_content'] ?? '');
        if ($index >= 0 && $index < count($news)) {
            if ($title !== '' && $content !== '') {
                $news[$index]['title'] = $title;
                $news[$index]['content'] = $content;
                file_put_contents($newsFile, json_encode($news, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                $_SESSION['message'] = 'Новина оновлена.';
            } else {
                $_SESSION['error'] = 'Поля не можуть бути порожніми.';
            }
        }
        header('Location: ' . $_SERVER['PHP_SELF'] . '?page=news');
        exit;
    }
    // Delete news
    if (isset($_POST['action']) && $_POST['action'] === 'delete_news') {
        $index = (int)($_POST['news_index'] ?? -1);
        if ($index >= 0 && $index < count($news)) {
            array_splice($news, $index, 1);
            file_put_contents($newsFile, json_encode($news, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            $_SESSION['message'] = 'Новина видалена.';
        }
        header('Location: ' . $_SERVER['PHP_SELF'] . '?page=news');
        exit;
    }
}

// Determine page (default to home)
// Determine page (default to home)
$page = $_GET['page'] ?? 'home';

// Handle logout action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit;
}

// Load releases for versions pages
$releasesFile = $dataDir . '/releases.json';
$releases = [];
if (file_exists($releasesFile)) {
    $jsonReleases = file_get_contents($releasesFile);
    $releases = json_decode($jsonReleases, true) ?: [];
}
// Capture and then clear messages
$message = $_SESSION['message'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['message'], $_SESSION['error']);

?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="CRM для управління категоріями, версіями та новинами">
    <title>Система CRM</title>
    <!-- Include Google Font from Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <!-- Include the custom theme (copied from original) -->
    <link href="../light.css" rel="stylesheet">
    <!-- Include Bootstrap 5 CSS from CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css.css" rel="stylesheet">
    <style>
        body {
            opacity: 0;
        }
    </style>
</head>
<body data-theme="default" data-layout="fluid" data-sidebar-position="left" data-sidebar-layout="default">
<div class="wrapper">
    <nav id="sidebar" class="sidebar js-sidebar">
        <div class="sidebar-content">
            <a class='sidebar-brand' href='index.php'>
                <span class="sidebar-brand-text align-middle">
                    Syrve
                    <sup><small class="badge bg-primary text-uppercase">PULSE</small></sup>
                </span>
            </a>
            <ul class="sidebar-nav">
                <li class="sidebar-header">
                    Навігація
                </li>
                <li class="sidebar-item <?php echo $page === 'home' ? 'active' : ''; ?>">
                    <a class="sidebar-link" href="?page=home">
                        <i class="align-middle" data-feather="bell"></i> <span class="align-middle">Актуальне</span>
                        <span class="sidebar-badge badge bg-primary">зараз</span>
                    </a>
                </li>
                <li class="sidebar-item <?php echo $page === 'news' ? 'active' : ''; ?>">
                    <a class="sidebar-link" href="?page=news">
                        <i class="align-middle" data-feather="calendar"></i> <span class="align-middle">Пульс</span>
                        <span class="sidebar-badge badge bg-primary">UA</span>
                    </a>
                </li>
                <li class="sidebar-item <?php echo $page === 'versions' || $page === 'release' ? 'active' : ''; ?>">
                    <a class="sidebar-link" href="?page=versions">
                        <i class="align-middle" data-feather="corner-right-down"></i> <span class="align-middle">Версії</span>
                    </a>
                </li>
                <li class="sidebar-item <?php echo $page === 'integrations' ? 'active' : ''; ?>">
                    <a class="sidebar-link" href="?page=integrations">
                        <i class="align-middle" data-feather="server"></i> <span class="align-middle">Інтеграції</span>
                        <span class="sidebar-badge badge bg-primary">UA</span>
                    </a>
                </li>
                <!-- Useful materials section -->
                <li class="sidebar-item">
                    <a class="sidebar-link d-flex align-items-center" data-bs-toggle="collapse" href="#usefulMenu" role="button" aria-expanded="<?php echo ($page === 'docs') ? 'true' : 'false'; ?>" aria-controls="usefulMenu">
                        <i class="align-middle" data-feather="gift"></i>
                        <span class="align-middle">Корисні матеріали</span>
                        <i class="align-middle ms-auto" data-feather="chevron-down"></i>
                    </a>
                    <ul class="sidebar-dropdown list-unstyled collapse <?php echo ($page === 'docs') ? 'show' : ''; ?>" id="usefulMenu">
                        <li class="sidebar-item <?php echo $page === 'docs' ? 'active' : ''; ?>">
                            <a class="sidebar-link" href="?page=docs">
                                <i class="align-middle" data-feather="book-open"></i> <span class="align-middle">Документація</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true): ?>
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                        <li class="sidebar-item <?php echo $page === 'admin' ? 'active' : ''; ?>">
                            <a class="sidebar-link" href="admin.php">
                                <i class="align-middle" data-feather="settings"></i> <span class="align-middle">Панель</span>
                            </a>
                        </li>
                    <?php endif; ?>
                    <li class="sidebar-item">
                        <form method="post" class="m-0">
                            <input type="hidden" name="logout" value="1">
                            <button type="submit" class="sidebar-link btn-as-link">
                                <i class="align-middle" data-feather="log-out"></i>
                                <span class="align-middle">Вихід</span>
                            </button>
                        </form>
                    </li>
                <?php else: ?>
                    <li class="sidebar-item">
                        <a class="sidebar-link" href="login.php">
                            <i class="align-middle" data-feather="lock"></i> <span class="align-middle">Вхід</span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
    <div class="main">
        <nav class="navbar navbar-expand navbar-light navbar-bg">
            <a class="sidebar-toggle js-sidebar-toggle">
                <i class="hamburger align-self-center"></i>
            </a>
        </nav>
        <main class="content">
            <div class="container-fluid p-0">
                <div class="row mb-3">
                    <div class="col">
                        <h3><strong>CRM</strong> панель</h3>
                    </div>
                </div>
                <?php if ($message): ?>
                    <div class="alert alert-success alert-dismissible" role="alert">
                        <?php echo htmlspecialchars($message); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible" role="alert">
                        <?php echo htmlspecialchars($error); ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if ($page === 'home'): ?>
                    <!-- Home section: show recommended versions and latest news events -->
                    <div class="row mb-2 mb-xl-3">
                        <div class="col-auto d-none d-sm-block">
                            <h3><strong>Syrve </strong> Pulse</h3>
                        </div>
                        <div class="col-auto ms-auto text-end mt-n1">
                            <p>Актуальне та важливе</p>
                        </div>
                    </div>
                    <div class="row">
                        <!-- Recommended Cloud version card -->
                        <div class="col-12 col-md-6 col-xxl d-flex">
                            <div class="card flex-fill">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col mt-0">
                                            <h5 class="card-title">Рекомендована версія для Cloud клієнтів</h5>
                                        </div>
                                        <div class="col-auto">
                                            <div class="stat">
                                                <i class="align-middle" data-feather="shopping-bag"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <h4 class="mt-0 mb-1">Syrve 9.1.8028 <span class="text-muted">вийшла у квітні 2025</span></h4>
                                    <div class="mb-0">
                                        <span class="badge badge-success-light">Стабільна для українського ринку</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- LT version card -->
                        <div class="col-12 col-md-6 col-xxl d-flex">
                            <div class="card flex-fill">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col mt-0">
                                            <h5 class="card-title">Версія для LT ліцензій</h5>
                                        </div>
                                        <div class="col-auto">
                                            <div class="stat">
                                                <i class="align-middle" data-feather="truck"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <h4 class="mt-0 mb-1">Syrve 8.9.9006 <span class="text-muted">вийшла у жовтні 2024</span></h4>
                                    <div class="mb-0">
                                        <span class="badge badge-success-light">Стабільна для українського ринку</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Latest news events -->
                    <div class="row mt-4">
                        <div class="col-12">
                            <h4 class="mb-3">Важливі події розвитку Syrve</h4>
                            <?php if (count($news) > 0): ?>
                                <?php foreach ($news as $n): ?>
                                    <div class="card mb-2">
                                        <div class="card-body">
                                            <h5 class="card-title mb-1"><?php echo htmlspecialchars($n['title']); ?></h5>
                                            <div class="text-muted mb-2" style="font-size: 0.875rem;">
                                                <?php echo htmlspecialchars($n['date']); ?>
                                            </div>
                                            <p class="card-text">
                                                <?php
                                                // Allow basic HTML markup in news content
                                                $allowedTags = '<ul><ol><li><pre><code><strong><em><b><i><u><p><br><a><img>';
                                                echo nl2br(strip_tags($n['content'], $allowedTags));
                                                ?>
                                            </p>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p>Подій немає.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php elseif ($page === 'integrations'): ?>
                    <!-- Integrations section: show plugin summary -->
                    <div class="row mb-2 mb-xl-3">
                        <div class="col-auto d-none d-sm-block">
                            <h3><strong>Syrve </strong> Інтеграції</h3>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <h4 class="mb-3">Офіційний ресурс з плагінами Syrve</h4>
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped align-middle">
                                    <thead>
                                        <tr>
                                            <th>Найменування</th>
                                            <th>Опис</th>
                                            <th>Поточна версія</th>
                                            <th>Мін. версія</th>
                                            <th>Дата оновлення</th>
                                            <th>Оберіть версію</th>
                                            <th>Дія</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($plugins as $plugin): ?>
                                            <?php $latest = end($plugin['versions']); ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($plugin['name']); ?></td>
                                                <td><?php echo htmlspecialchars($plugin['description']); ?></td>
                                                <td><?php echo htmlspecialchars($latest['version']); ?></td>
                                                <td><?php echo htmlspecialchars($latest['min_version']); ?></td>
                                                <td><?php echo htmlspecialchars($latest['date']); ?></td>
                                                <td>
                                                    <select class="form-select form-select-sm version-select" data-plugin="<?php echo htmlspecialchars($plugin['slug']); ?>">
                                                        <?php foreach ($plugin['versions'] as $ver): ?>
                                                            <option value="<?php echo rawurlencode($ver['file']); ?>">
                                                                <?php echo htmlspecialchars($ver['version']); ?> (<?php echo htmlspecialchars($ver['date']); ?>)
                                                            </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </td>
                                                <td>
                                                    <?php $firstFile = $plugin['versions'][0]['file'] ?? ''; ?>
                                                    <?php if (!empty($firstFile)): ?>
                                                        <a class="btn btn-sm btn-primary download-btn" href="plugins_files/<?php echo rawurlencode($plugin['slug']); ?>/<?php echo rawurlencode($firstFile); ?>" download>Завантажити</a>
                                                    <?php else: ?>
                                                        <span class="text-muted">Немає файлу</span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                <?php elseif ($page === 'versions'): ?>
                    <!-- Versions list page -->
                    <div class="card mb-3">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Версії Syrve</h5>
                        </div>
                        <div class="card-body">
                            <?php if (count($releases) > 0): ?>
                                <ul class="list-group">
                                    <?php foreach ($releases as $rel): ?>
                                        <li class="list-group-item d-flex justify-content-between align-items-center">
                                            <a href="?page=release&amp;slug=<?php echo urlencode($rel['slug']); ?>">
                                                <?php echo htmlspecialchars($rel['name']); ?>
                                            </a>
                                            <span class="badge bg-primary rounded-pill">Переглянути</span>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php else: ?>
                                <p>Релізи відсутні.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php elseif ($page === 'release'): ?>
                    <!-- Single release detail page -->
                    <?php
                    $slug = $_GET['slug'] ?? '';
                    $currentRelease = null;
                    foreach ($releases as $rel) {
                        if ($rel['slug'] === $slug) {
                            $currentRelease = $rel;
                            break;
                        }
                    }
                    ?>
                    <?php if ($currentRelease): ?>
                        <div class="row mb-2 mb-xl-3">
                            <div class="col-auto d-none d-sm-block">
                                <h3><strong><?php echo htmlspecialchars($currentRelease['name']); ?></strong></h3>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12 col-md-3 mb-3">
                                <!-- Category list -->
                                <div class="list-group" id="releaseCategories" role="tablist">
                                    <?php foreach ($currentRelease['categories'] as $key => $content): ?>
                                        <?php
                                        // map keys to human readable names
                                        $names = [
                                            'resume' => 'Резюме',
                                            'novelties' => 'Новинки',
                                            'forUkraine' => 'Для України',
                                            'fixed' => 'Виправлено',
                                            'important' => 'Важливе',
                                            'problems' => 'Відомі проблеми',
                                            'additions' => 'Доповнення',
                                            'lifehacks' => 'Лайфхаки'
                                        ];
                                        $title = $names[$key] ?? ucfirst($key);
                                        ?>
                                        <a class="list-group-item list-group-item-action" data-bs-toggle="list" href="#cat-<?php echo $key; ?>" role="tab">
                                            <?php echo htmlspecialchars($title); ?>
                                        </a>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <div class="col-12 col-md-9">
                                <div class="tab-content">
                                    <?php foreach ($currentRelease['categories'] as $key => $content): ?>
                                        <?php $title = $names[$key] ?? ucfirst($key); ?>
                                        <div class="tab-pane fade" id="cat-<?php echo $key; ?>" role="tabpanel">
                                            <div class="card mb-3">
                                                <div class="card-header">
                                                    <h5 class="card-title mb-0"><?php echo htmlspecialchars($title); ?></h5>
                                                </div>
                                                <div class="card-body">
                                                    <p><?php echo nl2br(htmlspecialchars($content)); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                        <script>
                        // Activate first tab by default
                        document.addEventListener('DOMContentLoaded', function() {
                            var firstTabTrigger = document.querySelector('#releaseCategories .list-group-item');
                            if (firstTabTrigger) {
                                var firstPane = document.querySelector('.tab-pane');
                                firstTabTrigger.classList.add('active');
                                if (firstPane) {
                                    firstPane.classList.add('show', 'active');
                                }
                            }
                        });
                        </script>
                    <?php else: ?>
                        <p>Реліз не знайдено.</p>
                    <?php endif; ?>
                <?php elseif ($page === 'docs'): ?>
                    <!-- Documentation page -->
                    <?php
                    $docsFile = $dataDir . '/docs.json';
                    $docs = [];
                    if (file_exists($docsFile)) {
                        $jsonDocs = file_get_contents($docsFile);
                        $docs = json_decode($jsonDocs, true) ?: [];
                    }
                    ?>
                    <div class="card mb-3">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Документація</h5>
                        </div>
                        <div class="card-body">
                            <?php if (count($docs) > 0): ?>
                                <?php foreach ($docs as $doc): ?>
                                    <div class="card mb-3">
                                        <div class="card-body">
                                            <h5 class="card-title mb-1"><?php echo htmlspecialchars($doc['title']); ?></h5>
                                            <div class="text-muted mb-2" style="font-size: 0.875rem;">
                                                <?php echo htmlspecialchars($doc['date']); ?>
                                            </div>
                                            <p class="card-text">
                                                <?php
                                                $allowedTags = '<ul><ol><li><pre><code><strong><em><b><i><u><p><br><a><img>';
                                                echo nl2br(strip_tags($doc['description'], $allowedTags));
                                                ?>
                                            </p>
                                            <?php if (!empty($doc['link'])): ?>
                                                <a href="<?php echo htmlspecialchars($doc['link']); ?>" class="btn btn-sm btn-outline-primary" target="_blank">Відкрити посилання</a>
                                            <?php endif; ?>
                                            <?php if (!empty($doc['file'])): ?>
                                                <a href="docs_files/<?php echo rawurlencode($doc['file']); ?>" class="btn btn-sm btn-primary" download>Завантажити файл</a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p>Документація відсутня.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php elseif ($page === 'news'): ?>
                    <!-- News page: display news list -->
                    <div class="card mb-3">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Новини</h5>
                        </div>
                        <div class="card-body">
                            <?php if (count($news) > 0): ?>
                                <?php foreach ($news as $i => $item): ?>
                                    <div class="card mb-3">
                                        <div class="card-body">
                                            <h5 class="card-title mb-1"><?php echo htmlspecialchars($item['title']); ?></h5>
                                            <div class="text-muted mb-2" style="font-size: 0.875rem;">
                                                <?php echo htmlspecialchars($item['date']); ?>
                                            </div>
                                            <p class="card-text">
                                                <?php
                                                $allowedTags = '<ul><ol><li><pre><code><strong><em><b><i><u><p><br><a><img>';
                                                echo nl2br(strip_tags($item['content'], $allowedTags));
                                                ?>
                                            </p>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p>Новини відсутні.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</div>
<!-- Include Bootstrap JS and Feather icons -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
<script>
    // Replace icons once page has loaded
    document.addEventListener('DOMContentLoaded', function() {
        feather.replace();
        // Fade in body once styles loaded
        document.body.style.opacity = '1';
        // Bind sidebar toggle
        document.querySelectorAll('.js-sidebar-toggle').forEach(function(toggle) {
            toggle.addEventListener('click', function() {
                document.querySelector('.sidebar').classList.toggle('collapsed');
            });
        });
        // Handle version selection for plugins
        document.querySelectorAll('.version-select').forEach(function(sel) {
            sel.addEventListener('change', function() {
                var slug = this.getAttribute('data-plugin');
                var file = this.value;
                var row = this.closest('tr');
                var btn = row.querySelector('.download-btn');
                if (btn) {
                    btn.href = 'plugins_files/' + slug + '/' + file;
                }
            });
        });
    });
</script>
</body>
</html>