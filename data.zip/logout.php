<?php require_once __DIR__.'/helpers.php';
logout();
header('Location: login.php'); exit;
