<?php
declare(strict_types=1);
require_once __DIR__.'/helpers.php';
$pdo = db(); migrate($pdo);
$page_title = 'Плагіни';
$q = trim((string)($_GET['q'] ?? ''));
$user_syrve = trim((string)($_GET['syrve'] ?? ''));
include __DIR__.'/partials_header.php';

$params = [];
$where = '';
if ($q !== '') {
    $where = "WHERE (p.name LIKE :q OR p.description LIKE :q)";
    $params[':q'] = "%$q%";
}

$cats = db_all($pdo, "SELECT * FROM categories ORDER BY sort,name");
$plugins = db_all($pdo, "
SELECT p.*, c.name AS cat_name, c.slug AS cat_slug
FROM plugins p JOIN categories c ON c.id=p.category_id
$where
ORDER BY c.sort, p.name", $params);

// prefetch versions per plugin
$pluginIds = array_map(fn($p)=>$p['id'], $plugins);
$versionsByPlugin = [];
if ($pluginIds) {
    $in = implode(',', array_fill(0, count($pluginIds), '?'));
    $rows = db_all($pdo, "
        SELECT v.* FROM plugin_versions v
        WHERE v.plugin_id IN ($in)
        ORDER BY v.created_at DESC", $pluginIds);
    foreach ($rows as $r) {
        $versionsByPlugin[$r['plugin_id']][] = $r;
    }
}

// helper to choose best version
function choose_version(array $versions, string $user_syrve): ?array {
    if (!$versions) return null;
    foreach ($versions as $v) {
        if (version_in_range($user_syrve, $v['syrve_min'], $v['syrve_max']) && !$v['is_prerelease']) {
            return $v; // first stable in chronological desc
        }
    }
    // fallback to first
    return $versions[0];
}

// files per version
function files_for_version(PDO $pdo, int $vid): array {
    return db_all($pdo, "SELECT * FROM plugin_files WHERE plugin_version_id=? ORDER BY created_at DESC", [$vid]);
}

?>

<section class="card">
  <form class="grid" action="plugins.php" method="get">
    <div class="col-8"><input type="search" name="q" value="<?=h($q)?>" placeholder="Пошук..."></div>
    <div class="col-4"><input type="text" name="syrve" value="<?=h($user_syrve)?>" placeholder="Ваша версія Syrve (напр. 7.7.6)"></div>
  </form>
  <p class="muted">Порада: введіть свою версію Syrve, і ми підсвітимо найбільш сумісні релізи.</p>
</section>

<?php
$current_cat = null;
foreach ($plugins as $p):
  if ($current_cat !== $p['cat_name']):
    if ($current_cat !== null) echo '</div>'; // close previous group
    $current_cat = $p['cat_name'];
    echo '<h2>'.h($current_cat).'</h2><div class="grid">';
  endif;
  $vers = $versionsByPlugin[$p['id']] ?? [];
  $best = $user_syrve !== '' ? choose_version($vers, $user_syrve) : ($vers[0] ?? null);
  $files = $best ? files_for_version($pdo, (int)$best['id']) : [];
?>
  <div class="col-12 card">
    <div class="flex between center">
      <h3><?=h($p['name'])?></h3>
      <?php if ($best): ?><span class="badge">Рекомендовано: <?=h($best['version'])?></span><?php endif; ?>
    </div>
    <div class="muted"><?=h($p['description'])?></div>
    <?php if ($best): ?>
      <div class="grid" style="margin-top:8px">
        <div class="col-8">
          <strong>Changelog:</strong>
          <div class="markdown"><?=$best['changelog_md']? md($best['changelog_md']) : '<p>—</p>'?></div>
        </div>
        <div class="col-4">
          <label>Інші версії</label>
          <select onchange="location=this.value">
            <option value="#">Обрати…</option>
            <?php foreach($vers as $v): ?>
              <option value="plugins.php?q=<?=urlencode($q)?>&syrve=<?=urlencode($user_syrve)?>#v<?=$v['id']?>">
                <?=$v['version']?> <?= $v['is_prerelease']?'(pre)':'' ?>
              </option>
            <?php endforeach; ?>
          </select>
          <label>Файли цієї версії</label>
          <?php if ($files): ?>
            <ul>
              <?php foreach($files as $f): ?>
                <li>
                  <a href="<?=h($f['path'])?>" download><?=h($f['filename'])?></a>
                  <small class="muted">(<?=h($f['kind'])?>, <?=number_format((int)$f['size_bytes']/1024,1)?> KB)</small>
                </li>
              <?php endforeach; ?>
            </ul>
          <?php else: ?>
            <p class="muted">Файлів немає</p>
          <?php endif; ?>
          <?php if (count($vers)>1): ?>
          <details>
            <summary>Інші файли</summary>
            <?php foreach($vers as $vv): if ($best && $vv['id']===$best['id']) continue;
                $fs = files_for_version($pdo, (int)$vv['id']); if (!$fs) continue; ?>
              <div>
                <strong>v<?=$vv['version']?></strong>
                <ul>
                  <?php foreach($fs as $f): ?>
                    <li><a href="<?=h($f['path'])?>" download><?=h($f['filename'])?></a></li>
                  <?php endforeach; ?>
                </ul>
              </div>
            <?php endforeach; ?>
          </details>
          <?php endif; ?>
        </div>
      </div>
    <?php else: ?>
      <p class="muted">Ще немає релізів.</p>
    <?php endif; ?>
  </div>
<?php endforeach; if ($current_cat !== null) echo '</div>'; ?>

<?php include __DIR__.'/partials_footer.php'; ?>
