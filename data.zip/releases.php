<?php
declare(strict_types=1);
require_once __DIR__.'/helpers.php';
$pdo = db(); migrate($pdo);
$page_title = 'Релізи плагінів';

$q = trim((string)($_GET['q'] ?? ''));
$cat = trim((string)($_GET['cat'] ?? ''));
$plugin = (int)($_GET['plugin'] ?? 0);
$with_pre = isset($_GET['pre']) ? 1 : 0;
$page = max(1, (int)($_GET['page'] ?? 1));
$per = 15;
$off = ($page-1)*$per;

include __DIR__.'/partials_header.php';

$params = [];
$where = "WHERE 1=1 ";
if ($q !== '') {
    $where .= "AND (pv.version LIKE :q OR pv.changelog_md LIKE :q OR p.name LIKE :q) ";
    $params[':q'] = "%$q%";
}
if ($cat !== '') {
    $where .= "AND c.slug = :cat ";
    $params[':cat'] = $cat;
}
if ($plugin > 0) {
    $where .= "AND p.id = :pid ";
    $params[':pid'] = $plugin;
}
if (!$with_pre) {
    $where .= "AND pv.is_prerelease = 0 ";
}

$total = db_one($pdo, "SELECT COUNT(*) AS cnt
FROM plugin_versions pv
JOIN plugins p ON p.id=pv.plugin_id
JOIN categories c ON c.id=p.category_id
$where", $params)['cnt'] ?? 0;

$rows = db_all($pdo, "
SELECT pv.*, p.name AS plugin_name, c.name AS cat_name, c.slug AS cat_slug,
       (SELECT COUNT(*) FROM plugin_files f WHERE f.plugin_version_id=pv.id) AS files_cnt
FROM plugin_versions pv
JOIN plugins p ON p.id=pv.plugin_id
JOIN categories c ON c.id=p.category_id
$where
ORDER BY pv.created_at DESC
LIMIT $per OFFSET $off", $params);

// fetch for filters
$cats = db_all($pdo,"SELECT * FROM categories ORDER BY sort,name");
$plugins = db_all($pdo,"SELECT id,name FROM plugins ORDER BY name");
?>
<section class="card">
  <form class="grid" action="releases.php" method="get">
    <div class="col-4"><input type="search" name="q" value="<?=h($q)?>" placeholder="Пошук по версії/чейнджлогу/плагіну"></div>
    <div class="col-3">
      <select name="cat">
        <option value="">Усі категорії</option>
        <?php foreach($cats as $c): ?>
          <option value="<?=$c['slug']?>" <?=$cat===$c['slug']?'selected':''?>><?=h($c['name'])?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-3">
      <select name="plugin">
        <option value="0">Усі плагіни</option>
        <?php foreach($plugins as $p): ?>
          <option value="<?=$p['id']?>" <?=$plugin===$p['id']?'selected':''?>><?=h($p['name'])?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-2">
      <label><input type="checkbox" name="pre" value="1" <?=$with_pre?'checked':''?>> Показувати pre‑релізи</label>
    </div>
  </form>
</section>

<section class="card">
  <h3>Знайдено: <?=$total?></h3>
  <table class="table">
    <tr>
      <th>Плагін</th><th>Категорія</th><th>Версія</th><th>Syrve</th><th>Файли</th><th>Дата</th><th></th>
    </tr>
    <?php foreach($rows as $r): ?>
      <tr id="v<?=$r['id']?>">
        <td><?=h($r['plugin_name'])?></td>
        <td><?=h($r['cat_name'])?></td>
        <td><?=h($r['version'])?> <?= $r['is_prerelease'] ? '<span class="badge">pre</span>' : '' ?></td>
        <td><?=h(($r['syrve_min']?:'').' — '.($r['syrve_max']?:''))?></td>
        <td><?=$r['files_cnt']?></td>
        <td><?=h($r['created_at'])?></td>
        <td><a class="btn" href="release_view.php?id=<?=$r['id']?>">Деталі</a></td>
      </tr>
    <?php endforeach; ?>
  </table>
  <?php
    $pages = max(1, ceil($total/$per));
    if ($pages>1):
  ?>
  <div class="flex gap center" style="margin-top:8px">
    <?php for($i=1;$i<=$pages;$i++):
      $qs = $_GET; $qs['page']=$i; $url='?'.http_build_query($qs); ?>
      <a class="btn <?=$i===$page?'active':''?>" href="<?=$url?>"><?=$i?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</section>

<?php include __DIR__.'/partials_footer.php'; ?>
